﻿class Complex {
    constructor(re, im) {
        this.re = re || 0;
        this.im = im || 0;
    }
}